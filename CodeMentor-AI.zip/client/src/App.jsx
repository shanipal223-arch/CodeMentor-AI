import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import EditorPanel from './components/EditorPanel';
import HealthScoreCard from './components/HealthScoreCard';
import AnalysisResults from './components/AnalysisResults';
import ApiKeyModal from './components/ApiKeyModal';
import HistoryDrawer from './components/HistoryDrawer';
import LoginModal from './components/LoginModal';
import { SAMPLE_CODES } from './constants/samples';
import { AlertTriangle, Sparkles, Key, ExternalLink, User } from 'lucide-react';

export default function App() {
  const defaultSample = SAMPLE_CODES[0];
  const [code, setCode] = useState(defaultSample.code);
  const [language, setLanguage] = useState(defaultSample.language);
  const [skillLevel, setSkillLevel] = useState(defaultSample.skillLevel);
  const [selectedSample, setSelectedSample] = useState(defaultSample.id);
  
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [errorBanner, setErrorBanner] = useState(null);

  const [apiKey, setApiKey] = useState(() => localStorage.getItem('codementor_openai_key') || '');
  const [serverStatus, setServerStatus] = useState(null);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [currentReviewId, setCurrentReviewId] = useState(null);

  // Student User Profile State
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('codementor_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('codementor_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('codementor_user');
  };


  // Fetch server status on mount or key change
  const fetchServerStatus = () => {
    fetch('/api/status')
      .then(res => res.json())
      .then(data => setServerStatus(data))
      .catch(err => {
        console.warn('Backend server status error:', err);
        setServerStatus({ status: 'offline', hasEnvKey: false });
      });
  };

  useEffect(() => {
    fetchServerStatus();
  }, []);


  // Save custom API key
  const handleSaveApiKey = (newKey) => {
    setApiKey(newKey);
    if (newKey) {
      localStorage.setItem('codementor_openai_key', newKey);
    } else {
      localStorage.removeItem('codementor_openai_key');
    }
  };

  // Handle sample selection
  const handleSelectSample = (sampleId) => {
    setSelectedSample(sampleId);
    const sample = SAMPLE_CODES.find(s => s.id === sampleId);
    if (sample) {
      setCode(sample.code);
      setLanguage(sample.language);
      setSkillLevel(sample.skillLevel);
    }
  };

  // Reset code to current sample or clear
  const handleResetCode = () => {
    const sample = SAMPLE_CODES.find(s => s.id === selectedSample);
    if (sample) {
      setCode(sample.code);
    } else {
      setCode('');
    }
    setAnalysis(null);
    setErrorBanner(null);
  };

  // Apply refactored code to the editor
  const handleApplyRefactor = (newCode) => {
    setCode(newCode);
  };

  // Load past review from MongoDB history
  const handleLoadReview = (review) => {
    if (!review) return;
    setCode(review.code || '');
    setLanguage(review.language || 'javascript');
    setSkillLevel(review.skillLevel || 'beginner');
    setAnalysis(review);
    setCurrentReviewId(review._id);
    setSelectedSample('');
  };


  // Perform code analysis
  const handleAnalyze = async () => {
    if (!code.trim()) {
      setErrorBanner('Please enter some code to analyze.');
      return;
    }

    setAnalyzing(true);
    setErrorBanner(null);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          language,
          skillLevel,
          apiKey: apiKey || undefined,
          userEmail: user?.email || undefined
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data = await res.json();
      setAnalysis(data);

      if (data.apiError) {
        setErrorBanner(`OpenAI Notice: ${data.apiError.details}`);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setErrorBanner(`Failed to analyze code: ${err.message}. Please check if the Node backend is running.`);
    } finally {
      setAnalyzing(false);
    }
  };

  // Analyze the default sample automatically on first load
  useEffect(() => {
    handleAnalyze();
  }, []);

  // Collect line numbers flagged by bugs for highlighting in the editor
  const flaggedLines = analysis?.bugs
    ? analysis.bugs.map(b => b.line).filter(Boolean)
    : [];

  return (
    <div className="min-h-screen flex flex-col bg-[#07090e] bg-mesh-glow text-slate-100 selection:bg-indigo-600/30">
      {/* Top Navbar Header */}
      <Header
        language={language}
        setLanguage={setLanguage}
        skillLevel={skillLevel}
        setSkillLevel={setSkillLevel}
        selectedSample={selectedSample}
        onSelectSample={handleSelectSample}
        onResetCode={handleResetCode}
        onAnalyze={handleAnalyze}
        analyzing={analyzing}
        apiKey={apiKey}
        serverStatus={serverStatus}
        onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        user={user}
        onOpenLogin={() => setIsLoginModalOpen(true)}
      />

      {/* Notice Banner (Offline Demo / API Key status) */}
      {!apiKey && !serverStatus?.hasEnvKey && (
        <div className="bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-blue-950/60 border-b border-indigo-500/20 px-4 py-2">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between text-xs text-indigo-200 gap-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
              <span>
                Running in <strong>Smart Student Demo Mode</strong>. Enter any code or select presets to test errors & clean coding guidance.
              </span>
            </div>
            <button
              onClick={() => setIsApiKeyModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 font-medium transition cursor-pointer"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Configure AI Key</span>
            </button>
          </div>
        </div>
      )}

      {/* Error / Alert banner */}
      {errorBanner && (
        <div className="bg-rose-950/50 border-b border-rose-800/60 px-4 py-2 text-xs text-rose-200 flex items-center justify-between">
          <div className="max-w-7xl mx-auto flex items-center gap-2 w-full">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorBanner}</span>
          </div>
        </div>
      )}

      {/* Main App Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 flex flex-col gap-4">
        {/* Code Health Score & Metrics Card */}
        {analysis && (
          <HealthScoreCard analysis={analysis} />
        )}

        {/* Two-Column IDE Layout */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-[580px]">
          {/* Left Column: Code Editor */}
          <div className="h-[580px] lg:h-full">
            <EditorPanel
              code={code}
              setCode={setCode}
              language={language}
              onAnalyze={handleAnalyze}
              analyzing={analyzing}
              flaggedLines={flaggedLines}
            />
          </div>

          {/* Right Column: AI Analysis & Learning Results */}
          <div className="h-[580px] lg:h-full">
            {analysis ? (
              <AnalysisResults
                analysis={analysis}
                code={code}
                language={language}
                skillLevel={skillLevel}
                apiKey={apiKey}
                onApplyRefactor={handleApplyRefactor}
              />
            ) : (
              <div className="h-full glass-panel rounded-2xl flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mb-4">
                  <Sparkles className="w-7 h-7 text-indigo-400 animate-pulse" />
                </div>
                <h3 className="text-base font-semibold text-white">Ready for Code Inspection</h3>
                <p className="text-xs text-slate-400 max-w-sm mt-1.5 leading-relaxed">
                  Click <strong className="text-indigo-300">"Analyze Code"</strong> or press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[11px] border border-slate-700">Ctrl + Enter</kbd> to inspect syntax bugs, Big-O complexity, and clean code standards.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* OpenAI Settings Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        apiKey={apiKey}
        onSaveApiKey={handleSaveApiKey}
        serverStatus={serverStatus}
        onReloadStatus={fetchServerStatus}
      />

      {/* MongoDB History Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onLoadReview={handleLoadReview}
        currentReviewId={currentReviewId}
        currentUser={user}
      />

      {/* Student Login / Profile Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        currentUser={user}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />


    </div>
  );
}
