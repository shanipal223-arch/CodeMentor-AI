export const SAMPLE_CODES = [
  {
    id: 'python-binary-search',
    name: 'Python: Buggy Binary Search (Off-by-One & Float Division)',
    language: 'python',
    skillLevel: 'beginner',
    code: `def binary_search(arr, target):
    low = 0
    high = len(arr) # Bug: should be len(arr) - 1
    
    # Bug: infinite loop when target is not present
    while low < high:
        # Bug: in Python 3, / returns float. Should use integer division //
        mid = (low + high) / 2
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid # Bug: should be mid + 1
        else:
            high = mid - 1
            
    return -1

# Test
numbers = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]
print("Index:", binary_search(numbers, 23))
`
  },
  {
    id: 'js-two-sum-quadratic',
    name: 'JavaScript: Two-Sum (Quadratic O(n²) Inefficient Loop)',
    language: 'javascript',
    skillLevel: 'beginner',
    code: `// Student implementation of Two Sum problem
// Inefficient O(n^2) time complexity
function findTwoSum(nums, target) {
    var result = [];
    
    // Nested loops checking every pair
    for (var i = 0; i < nums.length; i++) {
        for (var j = 0; j < nums.length; j++) {
            // Bug: checks the same element twice (i == j)
            if (nums[i] + nums[j] == target) {
                result.push(i);
                result.push(j);
                return result;
            }
        }
    }
    
    return null;
}

const list = [2, 7, 11, 15];
console.log(findTwoSum(list, 9));
`
  },
  {
    id: 'python-fibonacci-recursion',
    name: 'Python: Recursive Fibonacci (O(2^n) Exponential Bottleneck)',
    language: 'python',
    skillLevel: 'intermediate',
    code: `def fibonacci(n):
    # Missing negative input guard
    if n == 0:
        return 0
    if n == 1:
        return 1
    
    # Severe performance bottleneck: O(2^N) exponential time!
    # Recalculates overlapping subproblems millions of times
    return fibonacci(n - 1) + fibonacci(n - 2)

# Calling with n >= 35 causes browser/terminal to freeze
print("Fib(10):", fibonacci(10))
`
  },
  {
    id: 'js-async-leak',
    name: 'JavaScript: Unhandled Async & Missing Error Catch',
    language: 'javascript',
    skillLevel: 'intermediate',
    code: `async function fetchUserData(userId) {
    // Missing input validation
    const response = await fetch("https://api.example.com/users/" + userId);
    
    // Missing check for response.ok (e.g. 404, 500)
    const data = await response.json();
    
    // Potential TypeError if data.profile is undefined
    const email = data.profile.email.toLowerCase();
    
    return {
        id: userId,
        email: email,
        lastActive: new Date()
    };
}
`
  },
  {
    id: 'java-resource-leak',
    name: 'Java: Unclosed Stream & Missing Null Check',
    language: 'java',
    skillLevel: 'intermediate',
    code: `import java.io.*;
import java.util.*;

public class DataReader {
    public static List<String> readLines(String filename) throws Exception {
        // Resource leak: BufferedReader is never closed!
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        List<String> lines = new ArrayList<>();
        String line = null;
        
        while ((line = reader.readLine()) != null) {
            // NullPointerException risk if line is whitespace
            if (line.trim().length() > 0) {
                lines.add(line);
            }
        }
        
        // reader.close() is missing!
        return lines;
    }
}
`
  },
  {
    id: 'cpp-vector-bounds',
    name: 'C++: Vector Out of Bounds & Raw Pointers',
    language: 'cpp',
    skillLevel: 'intermediate',
    code: `#include <iostream>
#include <vector>

void processScores(const std::vector<int>& scores) {
    // Bug: accessing index size() is undefined behavior (out of bounds)
    for (int i = 0; i <= scores.size(); ++i) {
        std::cout << "Score " << i << ": " << scores[i] << std::endl;
    }
    
    // Memory leak: raw pointer allocated without delete
    int* tempBuffer = new int[100];
    tempBuffer[0] = 42;
    // Missing: delete[] tempBuffer;
}
`
  }
];

export const SUPPORTED_LANGUAGES = [
  { value: 'python', label: 'Python' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'java', label: 'Java' },
  { value: 'cpp', label: 'C++' },
  { value: 'csharp', label: 'C#' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
  { value: 'sql', label: 'SQL' }
];

export const SKILL_LEVELS = [
  { value: 'beginner', label: 'Beginner / Student' },
  { value: 'intermediate', label: 'Intermediate' },
  { value: 'advanced', label: 'Advanced' }
];
