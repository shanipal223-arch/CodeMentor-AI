import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Cpu, 
  Eye, 
  Lock,
  Sparkles,
  Volume2,
  VolumeX,
  ShieldCheck,
  TrendingUp,
  Award
} from 'lucide-react';

export default function HealthScoreCard({ analysis }) {
  const [isSpeaking, setIsSpeaking] = useState(false);

  if (!analysis) return null;

  const score = analysis.healthScore || 0;
  const ratings = analysis.ratings || {
    correctness: 80,
    performance: 75,
    readability: 85,
    security: 90
  };

  const getScoreTheme = (val) => {
    if (val >= 85) {
      return {
        color: '#10b981',
        textClass: 'text-emerald-400',
        bgClass: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300',
        label: 'Production Ready • Clean Architecture',
        badge: 'A+ Grade'
      };
    }
    if (val >= 70) {
      return {
        color: '#38bdf8',
        textClass: 'text-sky-400',
        bgClass: 'bg-sky-500/10 border-sky-500/20 text-sky-300',
        label: 'Good Quality • Minor Polish Recommended',
        badge: 'B Grade'
      };
    }
    if (val >= 50) {
      return {
        color: '#f59e0b',
        textClass: 'text-amber-400',
        bgClass: 'bg-amber-500/10 border-amber-500/20 text-amber-300',
        label: 'Needs Optimization & Error Handling',
        badge: 'C Grade'
      };
    }
    return {
      color: '#f43f5e',
      textClass: 'text-rose-400',
      bgClass: 'bg-rose-500/10 border-rose-500/20 text-rose-300',
      label: 'Critical Bugs or Runtime Flaws Present',
      badge: 'Action Needed'
    };
  };

  const theme = getScoreTheme(score);

  // Text to speech for AI summary
  const handleToggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in this browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      window.speechSynthesis.cancel();
      const textToSpeak = `Code health score is ${score} out of 100. ${analysis.summary || ''}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const metrics = [
    { label: 'Correctness', value: ratings.correctness, icon: CheckCircle2, barColor: 'from-emerald-500 to-teal-400' },
    { label: 'Performance', value: ratings.performance, icon: Cpu, barColor: 'from-blue-500 to-indigo-400' },
    { label: 'Readability', value: ratings.readability, icon: Eye, barColor: 'from-purple-500 to-pink-400' },
    { label: 'Security & Safety', value: ratings.security, icon: Lock, barColor: 'from-cyan-500 to-blue-400' },
  ];

  // SVG Radial meter calculations
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5 relative overflow-hidden transition-all">
      {/* Subtle top edge highlight */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/15 to-transparent"></div>

      <div className="flex flex-col lg:flex-row items-center justify-between gap-5">
        {/* Left: Radial Score Gauge & Executive Summary */}
        <div className="flex items-center gap-5 w-full lg:w-auto">
          {/* Circular SVG Gauge */}
          <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
            <svg className="w-20 h-20 transform -rotate-90">
              <circle
                cx="40"
                cy="40"
                r={radius}
                className="text-slate-800/80"
                strokeWidth="6"
                stroke="currentColor"
                fill="transparent"
              />
              <circle
                cx="40"
                cy="40"
                r={radius}
                stroke={theme.color}
                strokeWidth="6"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className={`text-2xl font-black tracking-tight ${theme.textClass}`}>
                {score}
              </span>
              <span className="text-[9px] uppercase tracking-wider text-slate-400 font-semibold">
                Score
              </span>
            </div>
          </div>

          {/* Verdict and AI Summary */}
          <div className="flex-1 space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${theme.bgClass}`}>
                {theme.label}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60 flex items-center gap-1">
                <Award className="w-3 h-3 text-amber-400" /> {theme.badge}
              </span>
              {/* Voice button */}
              <button
                onClick={handleToggleSpeech}
                className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition cursor-pointer ${
                  isSpeaking 
                    ? 'bg-indigo-600 border-indigo-400 text-white animate-pulse' 
                    : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700'
                }`}
                title={isSpeaking ? 'Stop Audio Explanation' : 'Listen to Audio Review'}
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span className="text-[10px] hidden sm:inline">{isSpeaking ? 'Mute' : 'Listen'}</span>
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl font-normal">
              {analysis.summary || 'Code evaluated successfully. Check the detailed tabs below for line-by-line findings.'}
            </p>
          </div>
        </div>

        {/* Right: 4 Dimension Metric Bars */}
        <div className="grid grid-cols-2 gap-x-5 gap-y-2.5 w-full lg:w-84 shrink-0 bg-slate-900/40 p-3 rounded-xl border border-white/[0.04]">
          {metrics.map((m) => {
            const Icon = m.icon;
            return (
              <div key={m.label} className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1 font-medium">
                    <Icon className="w-3 h-3 text-slate-400" />
                    {m.label}
                  </span>
                  <span className="font-mono text-slate-200 font-semibold">{m.value}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800/80 rounded-full overflow-hidden">
                  <div 
                    className={`h-full bg-gradient-to-r ${m.barColor} rounded-full transition-all duration-700 ease-out`}
                    style={{ width: `${Math.min(Math.max(m.value, 0), 100)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
