import React, { useState } from 'react';
import { 
  Key, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ExternalLink, 
  ShieldCheck, 
  Cpu, 
  Save, 
  RefreshCw,
  Gift,
  Zap,
  Sparkles
} from 'lucide-react';

export default function ApiKeyModal({ isOpen, onClose, apiKey, onSaveApiKey, serverStatus, onReloadStatus }) {
  const [tempKey, setTempKey] = useState(apiKey || '');
  const [tempBaseURL, setTempBaseURL] = useState('');
  const [tempModel, setTempModel] = useState('gemini-3.5-flash-lite');
  const [selectedProvider, setSelectedProvider] = useState('gemini');
  const [testing, setTesting] = useState(false);
  const [savingServer, setSavingServer] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [serverSaveMsg, setServerSaveMsg] = useState(null);

  if (!isOpen) return null;

  const handleProviderPreset = (provider) => {
    setSelectedProvider(provider);
    setTestResult(null);
    if (provider === 'gemini') {
      setTempBaseURL('');
      setTempModel('gemini-3.5-flash-lite');
    } else if (provider === 'groq') {
      setTempBaseURL('https://api.groq.com/openai/v1');
      setTempModel('llama-3.3-70b-versatile');
    } else if (provider === 'openai') {
      setTempBaseURL('');
      setTempModel('gpt-4o-mini');
    }
  };

  const handleSaveBrowser = () => {
    onSaveApiKey(tempKey.trim());
    onClose();
  };

  const handleSaveServer = async () => {
    if (!tempKey.trim()) {
      setServerSaveMsg({ success: false, message: 'Please enter an API key first.' });
      return;
    }
    setSavingServer(true);
    setServerSaveMsg(null);
    try {
      const res = await fetch('/api/save-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: tempKey.trim(),
          baseURL: tempBaseURL.trim() || undefined,
          model: tempModel,
          provider: selectedProvider !== 'auto' ? selectedProvider : undefined
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setServerSaveMsg({ success: true, message: 'Saved to server/.env and active in memory!' });
        onSaveApiKey(tempKey.trim());
        if (onReloadStatus) onReloadStatus();
      } else {
        setServerSaveMsg({ success: false, message: data.error || 'Failed to save to server.' });
      }
    } catch (err) {
      setServerSaveMsg({ success: false, message: 'Server connection error: ' + err.message });
    } finally {
      setSavingServer(false);
    }
  };

  const handleClear = () => {
    setTempKey('');
    setTempBaseURL('');
    onSaveApiKey('');
    setTestResult(null);
    setServerSaveMsg(null);
  };

  const testConnection = async () => {
    if (!tempKey.trim()) {
      setTestResult({
        success: false,
        message: 'Please paste your API key before testing.'
      });
      return;
    }

    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/test-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: tempKey.trim(),
          baseURL: tempBaseURL.trim() || undefined,
          model: tempModel,
          provider: selectedProvider !== 'auto' ? selectedProvider : undefined
        })
      });
      const data = await res.json();
      if (data.success) {
        setTestResult({
          success: true,
          message: data.message
        });
      } else {
        setTestResult({
          success: false,
          message: data.message || 'Verification failed. Please check your key quota and permissions.'
        });
      }
    } catch (err) {
      setTestResult({
        success: false,
        message: 'Could not reach backend: ' + err.message
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#0d121f] border border-white/[0.08] shadow-2xl p-6 text-slate-200 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center">
              <Key className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">AI Engine Configuration</h3>
              <p className="text-[11px] text-slate-400">Google Gemini (Free), Groq (Free), or OpenAI</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* Free Tier Callout Banner */}
        <div className="mt-4 p-3 rounded-xl bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-blue-950/40 border border-emerald-500/30 space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
            <Gift className="w-4 h-4 text-emerald-400" />
            <span>Need a 100% Free AI Key (No Credit Card)?</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Google Gemini gives a generous free tier for developers with high rate limits:
          </p>
          <div className="flex flex-wrap gap-2 pt-0.5">
            <a 
              href="https://aistudio.google.com/apikey"
              target="_blank"
              rel="noreferrer"
              className="px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center gap-1 transition"
            >
              <span>Get Free Gemini Key</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a 
              href="https://console.groq.com/keys"
              target="_blank"
              rel="noreferrer"
              className="px-2.5 py-1 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/40 text-cyan-300 text-xs font-medium flex items-center gap-1 transition"
            >
              <span>Get Free Groq Key</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Provider Preset Buttons */}
        <div className="mt-4">
          <label className="block text-[11px] font-medium text-slate-400 mb-1.5">
            Select Provider:
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handleProviderPreset('gemini')}
              className={`p-2.5 rounded-xl text-xs font-medium border text-center transition cursor-pointer ${
                selectedProvider === 'gemini'
                  ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950/30'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="font-semibold text-white">Google Gemini</div>
              <div className="text-[10px] text-emerald-400">Recommended</div>
            </button>

            <button
              type="button"
              onClick={() => handleProviderPreset('groq')}
              className={`p-2.5 rounded-xl text-xs font-medium border text-center transition cursor-pointer ${
                selectedProvider === 'groq'
                  ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-950/30'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="font-semibold text-white">Groq</div>
              <div className="text-[10px] text-cyan-400">Fast Llama 3</div>
            </button>

            <button
              type="button"
              onClick={() => handleProviderPreset('openai')}
              className={`p-2.5 rounded-xl text-xs font-medium border text-center transition cursor-pointer ${
                selectedProvider === 'openai'
                  ? 'bg-indigo-950/50 border-indigo-500 text-indigo-300 shadow-md shadow-indigo-950/30'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="font-semibold text-white">OpenAI</div>
              <div className="text-[10px] text-slate-400">GPT-4o mini</div>
            </button>
          </div>
        </div>

        <div className="mt-4 space-y-3.5">
          {/* API Key Input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              API Key:
            </label>
            <div className="relative">
              <input
                type="password"
                value={tempKey}
                onChange={(e) => setTempKey(e.target.value)}
                placeholder={
                  selectedProvider === 'gemini' 
                    ? 'AIzaSy...' 
                    : selectedProvider === 'groq'
                    ? 'gsk_...'
                    : 'sk-proj-...'
                }
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition shadow-inner"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400 inline" />
              Stored locally on your laptop; keys are never transmitted to third parties.
            </p>
          </div>

          {/* Model and Base URL */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                Model:
              </label>
              <input
                type="text"
                value={tempModel}
                onChange={(e) => setTempModel(e.target.value)}
                placeholder="gemini-3.5-flash-lite"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                Base URL (Optional):
              </label>
              <input
                type="text"
                value={tempBaseURL}
                onChange={(e) => setTempBaseURL(e.target.value)}
                placeholder="Auto"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Test connection alert */}
          {testResult && (
            <div className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
              testResult.success 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
            }`}>
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              )}
              <span className="leading-relaxed">{testResult.message}</span>
            </div>
          )}

          {/* Server save message */}
          {serverSaveMsg && (
            <div className={`p-2.5 rounded-xl text-xs flex items-center gap-2 border ${
              serverSaveMsg.success 
                ? 'bg-indigo-950/40 border-indigo-500/40 text-indigo-300' 
                : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-indigo-400" />
              <span>{serverSaveMsg.message}</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-2 pt-3.5 border-t border-white/[0.06]">
          <button
            onClick={testConnection}
            disabled={testing}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
          >
            {testing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-400" />
                <span>Verifying...</span>
              </>
            ) : (
              <span>Test Key Live</span>
            )}
          </button>
          
          <div className="flex items-center gap-2">
            {apiKey && (
              <button
                onClick={handleClear}
                className="px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-rose-950/30 transition cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              onClick={handleSaveServer}
              disabled={savingServer || !tempKey.trim()}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-xs font-semibold text-slate-200 transition disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
              title="Save to server/.env"
            >
              <Save className="w-3.5 h-3.5 text-indigo-400" />
              <span>{savingServer ? 'Saving...' : 'Save to .env'}</span>
            </button>
            <button
              onClick={handleSaveBrowser}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-lg shadow-indigo-600/30 transition cursor-pointer"
            >
              Apply in Browser
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
