import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, HelpCircle, MessageSquare } from 'lucide-react';

export default function StudentTutorChat({ code, language, analysis, apiKey }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: `Hi! I'm your CodeMentor tutor. Ask me anything about this ${language} code, time/space complexity, syntax errors, or how to write better edge tests!`
    }
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  const suggestedQuestions = [
    "Explain the Big-O time complexity simply",
    "Why does this issue happen on that line?",
    "How would a senior engineer write this?",
    "Give me 3 tricky edge cases to test"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, sending]);

  const handleSend = async (messageToSend) => {
    const text = messageToSend || input;
    if (!text.trim() || sending) return;

    const userMessage = { role: 'user', content: text };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSending(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          language,
          analysis,
          message: text,
          conversationHistory: messages.map(m => ({ role: m.role, content: m.content })),
          apiKey
        })
      });

      const data = await res.json();
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.reply || 'I am having trouble answering right now.'
      }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Error communicating with CodeMentor tutor: ' + err.message
      }]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-full rounded-xl border border-white/[0.06] bg-[#070a12] overflow-hidden">
      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
        {messages.map((msg, i) => {
          const isAssistant = msg.role === 'assistant';
          return (
            <div 
              key={i} 
              className={`flex items-start gap-2.5 ${isAssistant ? 'justify-start' : 'justify-end'}`}
            >
              {isAssistant && (
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-indigo-600/20">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                isAssistant 
                  ? 'bg-slate-900/90 border border-slate-800 text-slate-200 shadow-sm' 
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
              }`}>
                <div className="whitespace-pre-wrap">{msg.content}</div>
              </div>

              {!isAssistant && (
                <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {sending && (
          <div className="flex items-center gap-2.5 text-xs text-slate-400 bg-slate-900/80 px-3 py-2 rounded-xl border border-slate-800 w-fit">
            <Sparkles className="w-3.5 h-3.5 animate-spin text-indigo-400" />
            <span>CodeMentor AI tutor is drafting an explanation...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Question Chips */}
      <div className="px-3 py-2 bg-[#090d15] border-t border-white/[0.05] overflow-x-auto flex gap-1.5 no-scrollbar select-none">
        {suggestedQuestions.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSend(q)}
            disabled={sending}
            className="text-[11px] whitespace-nowrap px-3 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition disabled:opacity-50 cursor-pointer shadow-sm"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input bar */}
      <form 
        onSubmit={(e) => { e.preventDefault(); handleSend(); }}
        className="p-3 bg-[#0a0e18] border-t border-white/[0.06] flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Ask CodeMentor about this ${language} snippet...`}
          className="flex-1 bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition shadow-inner"
        />
        <button
          type="submit"
          disabled={!input.trim() || sending}
          className="h-8.5 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition disabled:opacity-50 cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
    </div>
  );
}
