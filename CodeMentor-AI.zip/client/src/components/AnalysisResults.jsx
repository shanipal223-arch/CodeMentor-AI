import React, { useState } from 'react';
import { 
  Bug, 
  Zap, 
  CheckCircle, 
  BookOpen, 
  Code, 
  FlaskConical, 
  MessageSquare,
  Copy, 
  Check, 
  ArrowRight,
  GitCompare,
  HelpCircle,
  Share2,
  ChevronRight,
  Sparkles,
  Download
} from 'lucide-react';
import StudentTutorChat from './StudentTutorChat';

export default function AnalysisResults({
  analysis,
  code,
  language,
  skillLevel,
  apiKey,
  onApplyRefactor
}) {
  const [activeTab, setActiveTab] = useState('bugs');
  const [copiedRefactor, setCopiedRefactor] = useState(false);
  const [generatingTests, setGeneratingTests] = useState(false);
  const [testCode, setTestCode] = useState(null);
  const [copiedTests, setCopiedTests] = useState(false);
  const [copiedMarkdown, setCopiedMarkdown] = useState(false);

  if (!analysis) return null;

  const bugs = analysis.bugs || [];
  const optimizations = analysis.optimizations || [];
  const bestPractices = analysis.bestPractices || [];
  const debuggingGuide = analysis.debuggingGuide || {
    mentalModel: "Trace inputs systematically through boundaries.",
    stepByStep: [],
    edgeCasesToTest: []
  };
  const refactoredCode = analysis.refactoredCode || code;

  const handleCopyRefactor = () => {
    navigator.clipboard.writeText(refactoredCode);
    setCopiedRefactor(true);
    setTimeout(() => setCopiedRefactor(false), 2000);
  };

  const handleGenerateTests = async () => {
    setGeneratingTests(true);
    try {
      const res = await fetch('/api/generate-tests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language, apiKey })
      });
      const data = await res.json();
      setTestCode(data.testCode || '// No unit tests generated');
    } catch (err) {
      setTestCode('// Failed to generate tests: ' + err.message);
    } finally {
      setGeneratingTests(false);
    }
  };

  const handleCopyTests = () => {
    if (!testCode) return;
    navigator.clipboard.writeText(testCode);
    setCopiedTests(true);
    setTimeout(() => setCopiedTests(false), 2000);
  };

  // Export full markdown summary
  const handleExportMarkdown = () => {
    const md = `# CodeMentor AI Review Report
**Language:** ${language} | **Skill Level:** ${skillLevel}
**Health Score:** ${analysis.healthScore}/100

## Summary
${analysis.summary}

## Bugs & Issues (${bugs.length})
${bugs.map((b, i) => `${i + 1}. **${b.title}** (Line ${b.line || 'N/A'}, Severity: ${b.severity})\n   ${b.explanation}\n`).join('\n')}

## Optimizations & Big-O
${optimizations.map((o) => `- **${o.title}**: ${o.currentComplexity || 'N/A'} -> ${o.optimizedComplexity || 'N/A'}\n  ${o.explanation}`).join('\n\n')}

## Refactored Code
\`\`\`${language}
${refactoredCode}
\`\`\`
`;
    navigator.clipboard.writeText(md);
    setCopiedMarkdown(true);
    setTimeout(() => setCopiedMarkdown(false), 2500);
  };

  const tabs = [
    { id: 'bugs', label: 'Bugs & Flaws', icon: Bug, count: bugs.length, color: 'text-rose-400' },
    { id: 'optimizations', label: 'Big-O & Speed', icon: Zap, count: optimizations.length, color: 'text-amber-400' },
    { id: 'diff', label: 'Diff View', icon: GitCompare, count: null, color: 'text-emerald-400' },
    { id: 'bestPractices', label: 'Clean Code', icon: CheckCircle, count: bestPractices.length, color: 'text-blue-400' },
    { id: 'debuggingGuide', label: 'Tutor Guide', icon: BookOpen, count: null, color: 'text-purple-400' },
    { id: 'refactored', label: 'Refactored', icon: Code, count: null, color: 'text-indigo-400' },
    { id: 'tests', label: 'Tests', icon: FlaskConical, count: null, color: 'text-cyan-400' },
    { id: 'chat', label: 'AI Chat', icon: MessageSquare, count: null, color: 'text-violet-400' },
  ];

  return (
    <div className="glass-panel flex flex-col h-full rounded-2xl overflow-hidden relative shadow-2xl transition-all">
      {/* Tabs Header Navigation */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#0a0e17]/90 border-b border-white/[0.06] select-none gap-2">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-800 text-white shadow-sm border border-slate-700/80'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${tab.color}`} />
                <span>{tab.label}</span>
                {tab.count !== null && tab.count > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Export Report Quick Action */}
        <button
          onClick={handleExportMarkdown}
          className="shrink-0 flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 transition cursor-pointer"
          title="Copy Markdown Report for Assignment / Submission"
        >
          {copiedMarkdown ? <Check className="w-3 h-3 text-emerald-400" /> : <Share2 className="w-3 h-3 text-slate-400" />}
          <span className="hidden sm:inline">{copiedMarkdown ? 'Copied Report!' : 'Export Report'}</span>
        </button>
      </div>

      {/* Panels Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 bg-[#060910]">
        {/* 1. BUGS & ERRORS TAB */}
        {activeTab === 'bugs' && (
          <div className="space-y-3">
            {bugs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 flex flex-col items-center justify-center space-y-2">
                <CheckCircle className="w-10 h-10 text-emerald-400" />
                <h4 className="text-sm font-semibold text-white">No Critical Bugs Found</h4>
                <p className="text-xs text-slate-400 max-w-sm">
                  Your code passes syntax, bounds, and edge condition inspections. Check the Big-O and Clean Code tabs for optimizations!
                </p>
              </div>
            ) : (
              bugs.map((bug, index) => {
                const isCrit = bug.severity === 'critical';
                const isWarn = bug.severity === 'warning';
                return (
                  <div 
                    key={index} 
                    className={`p-4 rounded-xl border transition-all ${
                      isCrit 
                        ? 'bg-rose-950/20 border-rose-500/30' 
                        : isWarn
                        ? 'bg-amber-950/20 border-amber-500/30'
                        : 'bg-blue-950/20 border-blue-500/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${
                          isCrit
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            : isWarn
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                            : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                        }`}>
                          {bug.severity || 'issue'}
                        </span>
                        {bug.line && (
                          <span className="text-[11px] font-mono text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-700/60">
                            Line {bug.line}
                          </span>
                        )}
                        <h4 className="text-xs font-semibold text-white">{bug.title}</h4>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                      {bug.explanation}
                    </p>

                    {bug.fix && (
                      <div className="bg-[#090d15] rounded-lg p-3 border border-white/[0.06]">
                        <div className="text-[11px] font-semibold text-emerald-400 mb-1 flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> Suggested Fix:
                        </div>
                        <pre className="text-xs text-slate-200 font-mono-code overflow-x-auto whitespace-pre-wrap">
                          {bug.fix}
                        </pre>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* 2. OPTIMIZATIONS & BIG-O TAB */}
        {activeTab === 'optimizations' && (
          <div className="space-y-4">
            {optimizations.length === 0 ? (
              <div className="p-8 text-center text-slate-400 flex flex-col items-center">
                <Zap className="w-10 h-10 text-amber-400 mb-2" />
                <h4 className="text-sm font-semibold text-white">Algorithmic Efficiency is Optimal</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  No redundant nested iterations or exponential bottlenecks detected.
                </p>
              </div>
            ) : (
              optimizations.map((opt, index) => (
                <div key={index} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-amber-400" />
                      {opt.title}
                    </h4>
                    {opt.technique && (
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20 font-medium">
                        Concept: {opt.technique}
                      </span>
                    )}
                  </div>

                  {/* Complexity Comparison Badge */}
                  {(opt.currentComplexity || opt.optimizedComplexity) && (
                    <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#060910] border border-slate-800 text-xs">
                      <div className="flex items-center gap-1.5 text-rose-400">
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Current:</span>
                        <code className="font-mono bg-rose-950/40 px-1.5 py-0.5 rounded border border-rose-800/50">
                          {opt.currentComplexity || 'O(n²)'}
                        </code>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
                      <div className="flex items-center gap-1.5 text-emerald-400">
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Optimized:</span>
                        <code className="font-mono bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/50">
                          {opt.optimizedComplexity || 'O(n)'}
                        </code>
                      </div>
                    </div>
                  )}

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {opt.explanation}
                  </p>
                </div>
              ))
            )}
          </div>
        )}

        {/* 3. DIFF VIEW TAB (Side-by-Side Before vs After) */}
        {activeTab === 'diff' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
              <span className="text-xs text-slate-400">
                Visual Comparison: Original Input vs. AI Optimized Code
              </span>
              <button
                onClick={() => onApplyRefactor(refactoredCode)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 transition cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>Apply to Editor</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Original */}
              <div className="rounded-xl border border-rose-500/20 bg-rose-950/10 overflow-hidden">
                <div className="px-3 py-1.5 bg-rose-950/30 border-b border-rose-500/20 text-[11px] font-semibold text-rose-300 flex items-center justify-between">
                  <span>Original Code (Student)</span>
                  <span className="text-[10px] font-mono text-rose-400">Before</span>
                </div>
                <div className="p-3 text-xs font-mono-code text-slate-300 overflow-x-auto max-h-[380px] whitespace-pre">
                  {code}
                </div>
              </div>

              {/* Refactored */}
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-950/10 overflow-hidden">
                <div className="px-3 py-1.5 bg-emerald-950/30 border-b border-emerald-500/20 text-[11px] font-semibold text-emerald-300 flex items-center justify-between">
                  <span>Refactored Code (AI)</span>
                  <span className="text-[10px] font-mono text-emerald-400">After</span>
                </div>
                <div className="p-3 text-xs font-mono-code text-emerald-200 overflow-x-auto max-h-[380px] whitespace-pre">
                  {refactoredCode}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4. CLEAN CODE & BEST PRACTICES TAB */}
        {activeTab === 'bestPractices' && (
          <div className="space-y-3">
            {bestPractices.map((bp, index) => (
              <div key={index} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    {bp.category || 'Standard'}
                  </span>
                  <h4 className="text-xs font-bold text-white flex-1 ml-2">{bp.tip}</h4>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {bp.explanation}
                </p>

                {bp.codeExample && (
                  <div className="bg-[#090d15] rounded-lg p-3 border border-white/[0.06]">
                    <pre className="text-xs text-slate-200 font-mono-code overflow-x-auto whitespace-pre-wrap">
                      {bp.codeExample}
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* 5. STUDENT DEBUGGING GUIDE TAB */}
        {activeTab === 'debuggingGuide' && (
          <div className="space-y-4">
            {/* Mental Model */}
            {debuggingGuide.mentalModel && (
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/30 to-indigo-950/30 border border-purple-500/30">
                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300 mb-1.5">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  Engineering Mental Model:
                </div>
                <p className="text-xs text-slate-200 leading-relaxed italic">
                  "{debuggingGuide.mentalModel}"
                </p>
              </div>
            )}

            {/* Step-by-Step Walkthrough */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-indigo-400" />
                Step-by-Step Debugging Process:
              </h4>
              <div className="space-y-2">
                {debuggingGuide.stepByStep?.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 bg-[#090d15] p-3 rounded-lg border border-slate-800">
                    <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Edge Cases to Test */}
            {debuggingGuide.edgeCasesToTest && debuggingGuide.edgeCasesToTest.length > 0 && (
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-2">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-cyan-400" />
                  Crucial Edge Cases to Verify:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  {debuggingGuide.edgeCasesToTest.map((ec, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2.5 rounded-lg bg-[#090d15] border border-slate-800 text-xs text-slate-300">
                      <ChevronRight className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{ec}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* 6. REFACTORED CODE TAB */}
        {activeTab === 'refactored' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
              <span className="text-xs text-slate-400">
                Optimized and production-ready implementation
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyRefactor}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition cursor-pointer"
                >
                  {copiedRefactor ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedRefactor ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={() => onApplyRefactor(refactoredCode)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 transition cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>Apply to Editor</span>
                </button>
              </div>
            </div>

            <div className="bg-[#060910] rounded-xl border border-white/[0.06] p-4 font-mono-code text-xs text-slate-100 overflow-x-auto leading-6">
              <pre className="whitespace-pre-wrap">{refactoredCode}</pre>
            </div>
          </div>
        )}

        {/* 7. UNIT TESTS TAB */}
        {activeTab === 'tests' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-semibold text-white">Automated Student Unit Tests</h4>
                <p className="text-[11px] text-slate-400">Generates test suites for edge cases & happy paths</p>
              </div>
              <div className="flex items-center gap-2">
                {testCode && (
                  <button
                    onClick={handleCopyTests}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition cursor-pointer"
                  >
                    {copiedTests ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedTests ? 'Copied' : 'Copy Tests'}</span>
                  </button>
                )}
                <button
                  onClick={handleGenerateTests}
                  disabled={generatingTests}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-semibold text-white transition disabled:opacity-50 cursor-pointer shadow-md shadow-cyan-600/25"
                >
                  <FlaskConical className="w-3.5 h-3.5" />
                  <span>{generatingTests ? 'Synthesizing...' : 'Generate Test Suite'}</span>
                </button>
              </div>
            </div>

            {testCode ? (
              <div className="bg-[#060910] rounded-xl border border-white/[0.06] p-4 font-mono-code text-xs text-slate-100 overflow-x-auto leading-6">
                <pre className="whitespace-pre-wrap">{testCode}</pre>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 flex flex-col items-center justify-center space-y-2 border border-dashed border-slate-800 rounded-xl">
                <FlaskConical className="w-8 h-8 text-cyan-400" />
                <p className="text-xs text-slate-300">Click "Generate Test Suite" to synthesize automated test assertions for this function.</p>
              </div>
            )}
          </div>
        )}

        {/* 8. STUDENT TUTOR CHAT TAB */}
        {activeTab === 'chat' && (
          <StudentTutorChat
            code={code}
            language={language}
            analysis={analysis}
            apiKey={apiKey}
          />
        )}
      </div>
    </div>
  );
}
