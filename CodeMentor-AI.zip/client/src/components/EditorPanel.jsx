import React, { useRef, useState } from 'react';
import { Copy, Check, Terminal, FileCode, AlertTriangle, Trash2 } from 'lucide-react';

export default function EditorPanel({
  code,
  setCode,
  language,
  onAnalyze,
  analyzing,
  flaggedLines = []
}) {
  const [copied, setCopied] = useState(false);
  const textareaRef = useRef(null);

  const lines = code.split('\n');
  const lineCount = Math.max(lines.length, 1);

  const getFileExtension = (lang) => {
    switch (lang) {
      case 'python': return 'py';
      case 'javascript': return 'js';
      case 'typescript': return 'ts';
      case 'java': return 'java';
      case 'cpp': return 'cpp';
      case 'c': return 'c';
      case 'go': return 'go';
      case 'rust': return 'rs';
      default: return 'txt';
    }
  };

  const handleKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!analyzing) {
        onAnalyze();
      }
      return;
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.target;
      const start = target.selectionStart;
      const end = target.selectionEnd;

      const indentation = '    '; // 4 spaces
      const newCode = code.substring(0, start) + indentation + code.substring(end);
      setCode(newCode);

      setTimeout(() => {
        target.selectionStart = target.selectionEnd = start + indentation.length;
      }, 0);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="glass-panel flex flex-col h-full rounded-2xl overflow-hidden relative shadow-2xl transition-all">
      {/* IDE Window Title Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#0a0e17]/90 border-b border-white/[0.06] select-none">
        {/* Left: Window dots & File Tab */}
        <div className="flex items-center gap-3">
          {/* macOS window dots */}
          <div className="flex items-center gap-1.5 opacity-80">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block"></span>
          </div>

          {/* Active File Tab */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900/90 border border-slate-700/60 text-xs font-mono text-slate-200 shadow-sm">
            <FileCode className="w-3.5 h-3.5 text-indigo-400" />
            <span>solution.{getFileExtension(language)}</span>
          </div>

          {flaggedLines.length > 0 && (
            <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-rose-400" />
              {flaggedLines.length} issue{flaggedLines.length > 1 ? 's' : ''} detected
            </span>
          )}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
            {lineCount} lines • {code.length} chars
          </span>
          <button
            onClick={() => setCode('')}
            title="Clear Editor"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 transition cursor-pointer"
            title="Copy Code"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>

      {/* Editor Body with Line Numbers */}
      <div className="relative flex-1 flex overflow-hidden font-mono-code text-[13px] leading-6 bg-[#060910]">
        {/* Line Numbers Column */}
        <div className="select-none py-3 px-3 text-right text-slate-600 bg-[#090d15]/80 border-r border-white/[0.05] font-mono shrink-0">
          {Array.from({ length: lineCount }).map((_, i) => {
            const lineNum = i + 1;
            const isFlagged = flaggedLines.includes(lineNum);
            return (
              <div 
                key={i} 
                className={`h-6 flex items-center justify-end px-1 rounded transition-colors ${
                  isFlagged 
                    ? 'text-rose-400 font-bold bg-rose-950/50 border-r-2 border-rose-500' 
                    : 'text-slate-600'
                }`}
                title={isFlagged ? `Issue identified on line ${lineNum}` : undefined}
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        {/* Code Textarea */}
        <div className="relative flex-1 h-full overflow-auto">
          <textarea
            ref={textareaRef}
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`// Paste your ${language} code here...\n// CodeMentor AI will inspect bugs, Big-O complexity, security flaws, and clean code standards.`}
            spellCheck="false"
            className="w-full h-full p-3.5 bg-transparent text-slate-100 placeholder-slate-600 resize-none focus:outline-none font-mono-code text-[13px] leading-6 whitespace-pre selection:bg-indigo-600/30"
            style={{ tabSize: 4 }}
          />
        </div>
      </div>

      {/* Bottom Status Bar */}
      <div className="px-4 py-2 bg-[#090d15] border-t border-white/[0.05] flex items-center justify-between text-[11px] text-slate-400 select-none">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-indigo-400" />
          <span>Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px] border border-slate-700">Ctrl + Enter</kbd> to analyze</span>
        </div>
        <div className="flex items-center gap-3 text-slate-500">
          <span className="uppercase text-[10px] font-semibold text-indigo-400/80">{language}</span>
          <span>Spaces: 4</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
}
