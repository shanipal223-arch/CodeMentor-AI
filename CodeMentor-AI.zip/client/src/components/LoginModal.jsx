import React, { useState } from 'react';
import { 
  Mail, 
  User, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight,
  LogOut,
  FolderGit2
} from 'lucide-react';

export default function LoginModal({
  isOpen,
  onClose,
  currentUser,
  onLogin,
  onLogout
}) {
  const [email, setEmail] = useState(currentUser?.email || '');
  const [name, setName] = useState(currentUser?.name || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  if (!isOpen) return null;

  const validateEmail = (val) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address (e.g. student@college.edu).');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          name: name.trim() || undefined
        })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSuccessMsg(data.message || 'Login successful!');
        onLogin(data.user);
        setTimeout(() => {
          onClose();
        }, 800);
      } else {
        setError(data.error || 'Failed to sign in.');
      }
    } catch (err) {
      // Local fallback in case network is offline
      const fallbackUser = {
        email: email.trim().toLowerCase(),
        name: name.trim() || email.trim().split('@')[0],
        loginAt: new Date().toISOString()
      };
      onLogin(fallbackUser);
      setSuccessMsg(`Welcome, ${fallbackUser.name}!`);
      setTimeout(() => {
        onClose();
      }, 800);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = () => {
    setEmail('student@university.edu');
    setName('Alex Morgan');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl bg-[#0c101d] border border-white/[0.08] shadow-2xl p-6 text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/20">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {currentUser ? 'Student Profile' : 'Sign In to CodeMentor'}
              </h3>
              <p className="text-[11px] text-slate-400">Save code reviews, track health scores & sync history</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* If currently logged in */}
        {currentUser ? (
          <div className="py-4 space-y-4">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center text-lg font-bold shadow-md">
                {(currentUser.name || currentUser.email || 'U')[0].toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-semibold text-white truncate">
                  {currentUser.name || 'Student'}
                </h4>
                <p className="text-xs text-slate-400 truncate flex items-center gap-1 mt-0.5">
                  <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>{currentUser.email}</span>
                </p>
                <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Active Student Account</span>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-white/[0.05] text-xs text-slate-300 space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-300 font-medium text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Account Benefits Active:</span>
              </div>
              <ul className="list-disc list-inside text-[11px] text-slate-400 space-y-0.5 pl-1">
                <li>Reviews are automatically tagged with your email</li>
                <li>History persists across laptop restarts</li>
                <li>Customized AI mentor responses</li>
              </ul>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={onLogout}
                className="px-4 py-2 rounded-xl bg-rose-950/30 hover:bg-rose-950/60 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          /* Sign In Form */
          <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Email Address <span className="text-indigo-400">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition shadow-inner"
                  autoFocus
                />
              </div>
            </div>

            {/* Name Field (Optional) */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Your Name <span className="text-slate-500 text-[11px] font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Shani Pal"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition shadow-inner"
                />
              </div>
            </div>

            {/* Error / Success alerts */}
            {error && (
              <div className="p-2.5 rounded-xl text-xs flex items-center gap-2 border bg-rose-950/40 border-rose-500/40 text-rose-300">
                <AlertCircle className="w-3.5 h-3.5 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-2.5 rounded-xl text-xs flex items-center gap-2 border bg-emerald-950/40 border-emerald-500/40 text-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Feature Perks */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-white/[0.05] text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 text-indigo-300 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Why Sign In?</span>
              </div>
              <p>Your reviews, Big-O metrics, and AI chats will be tied to your email ID and stored safely in your database.</p>
            </div>

            {/* Demo email chip */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
              <span>Quick fill for testing:</span>
              <button
                type="button"
                onClick={handleQuickDemo}
                className="text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
              >
                Use sample student ID
              </button>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-between gap-2 border-t border-white/[0.06]">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={loading || !email.trim()}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition disabled:opacity-50 cursor-pointer"
              >
                {loading ? (
                  <span>Signing In...</span>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
