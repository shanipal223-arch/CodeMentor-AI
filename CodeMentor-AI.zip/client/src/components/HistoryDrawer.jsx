import React, { useState, useEffect } from 'react';
import { 
  X, 
  Trash2, 
  ArrowRight, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ExternalLink, 
  RefreshCw,
  FolderOpen
} from 'lucide-react';

export default function HistoryDrawer({
  isOpen,
  onClose,
  onLoadReview,
  currentReviewId,
  currentUser
}) {
  const [historyList, setHistoryList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mongoStatus, setMongoStatus] = useState(null);
  const [mongoUri, setMongoUri] = useState('');
  const [savingMongo, setSavingMongo] = useState(false);
  const [mongoMsg, setMongoMsg] = useState(null);
  const [showConfig, setShowConfig] = useState(false);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const url = currentUser?.email 
        ? `/api/history?email=${encodeURIComponent(currentUser.email)}`
        : '/api/history';
      const res = await fetch(url);
      const data = await res.json();
      setHistoryList(data.history || []);
      setMongoStatus(data.mongo || null);
    } catch (err) {
      console.warn('Failed to fetch history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen]);

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    try {
      await fetch(`/api/history/${id}`, { method: 'DELETE' });
      setHistoryList(prev => prev.filter(item => item._id !== id));
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleSelectReview = async (id) => {
    try {
      const res = await fetch(`/api/history/${id}`);
      const review = await res.json();
      if (review && review.code) {
        onLoadReview(review);
        onClose();
      }
    } catch (err) {
      console.error('Error loading review:', err);
    }
  };

  const handleSaveMongoUri = async () => {
    if (!mongoUri.trim()) return;
    setSavingMongo(true);
    setMongoMsg(null);
    try {
      const res = await fetch('/api/save-mongo-uri', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uri: mongoUri.trim() })
      });
      const data = await res.json();
      setMongoMsg({
        success: data.connected,
        message: data.message
      });
      if (data.mongo) setMongoStatus(data.mongo);
      fetchHistory();
    } catch (err) {
      setMongoMsg({ success: false, message: 'Connection error: ' + err.message });
    } finally {
      setSavingMongo(false);
    }
  };

  const formatTime = (isoString) => {
    if (!isoString) return '';
    const date = new Date(isoString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (score >= 60) return 'text-sky-400 bg-sky-500/10 border-sky-500/30';
    return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md h-full bg-[#0a0e18] border-l border-white/[0.08] shadow-2xl flex flex-col text-slate-200 animate-in slide-in-from-right duration-250">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/[0.06] bg-[#0c1220]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center">
              <Database className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Review History</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                  {historyList.length}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">MongoDB Atlas & Local Store</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={fetchHistory}
              disabled={loading}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Database Status Strip */}
        <div className="px-4 py-2.5 bg-slate-900/60 border-b border-white/[0.05] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${mongoStatus?.connected ? 'bg-emerald-400 animate-pulse' : 'bg-sky-400'}`} />
            <span className="text-slate-300 font-medium text-[11px]">
              {mongoStatus?.connected ? 'MongoDB Connected' : 'Local JSON Database'}
            </span>
          </div>
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="text-[11px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
          >
            {showConfig ? 'Hide Config' : 'MongoDB Setup'}
          </button>
        </div>

        {/* MongoDB Connection Form (Togglable) */}
        {showConfig && (
          <div className="p-4 bg-slate-900/90 border-b border-white/[0.06] space-y-2.5 text-xs">
            <label className="block text-slate-300 font-medium text-[11px]">
              MongoDB Connection URI:
            </label>
            <input
              type="password"
              value={mongoUri}
              onChange={(e) => setMongoUri(e.target.value)}
              placeholder="mongodb+srv://user:pass@cluster.mongodb.net/codementor"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            <div className="flex items-center justify-between">
              <a 
                href="https://www.mongodb.com/cloud/atlas/register" 
                target="_blank" 
                rel="noreferrer" 
                className="text-[11px] text-emerald-400 hover:underline flex items-center gap-0.5"
              >
                Free MongoDB Atlas <ExternalLink className="w-2.5 h-2.5" />
              </a>
              <button
                onClick={handleSaveMongoUri}
                disabled={savingMongo || !mongoUri.trim()}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition disabled:opacity-50 cursor-pointer shadow-md shadow-emerald-600/20"
              >
                {savingMongo ? 'Connecting...' : 'Connect'}
              </button>
            </div>
            {mongoMsg && (
              <div className={`p-2 rounded-lg text-[11px] flex items-center gap-1.5 border ${
                mongoMsg.success ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300' : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
              }`}>
                {mongoMsg.success ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <AlertCircle className="w-3.5 h-3.5 text-rose-400" />}
                <span>{mongoMsg.message}</span>
              </div>
            )}
          </div>
        )}

        {/* Reviews List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 bg-[#070a12]">
          {historyList.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2">
              <FolderOpen className="w-10 h-10 text-slate-600" />
              <h4 className="text-sm font-semibold text-white">No Reviews Yet</h4>
              <p className="text-xs text-slate-400 max-w-xs">
                Every code review you run will automatically be archived here!
              </p>
            </div>
          ) : (
            historyList.map((item) => {
              const isSelected = currentReviewId === item._id;
              return (
                <div
                  key={item._id}
                  onClick={() => handleSelectReview(item._id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer group ${
                    isSelected
                      ? 'bg-indigo-950/30 border-indigo-500/60 shadow-lg shadow-indigo-950/20'
                      : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${getScoreColor(item.healthScore)}`}>
                        {item.healthScore}%
                      </span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold border border-slate-700/60">
                        {item.language}
                      </span>
                    </div>
                    <button
                      onClick={(e) => handleDelete(item._id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 rounded transition cursor-pointer"
                      title="Delete review"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h4 className="text-xs font-semibold text-white truncate mb-1">
                    {item.title}
                  </h4>

                  {item.summary && (
                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed mb-2 font-normal">
                      {item.summary}
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1.5 border-t border-white/[0.05]">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTime(item.createdAt)}
                    </span>
                    <span className="text-indigo-400 font-medium group-hover:translate-x-0.5 transition flex items-center gap-0.5">
                      Load Review <ArrowRight className="w-2.5 h-2.5 inline" />
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
