import React from 'react';
import { 
  Sparkles, 
  Code2, 
  Key, 
  Play, 
  RotateCcw, 
  GraduationCap, 
  Database,
  ChevronDown,
  Layers,
  Cpu,
  LogIn,
  User
} from 'lucide-react';
import { SUPPORTED_LANGUAGES, SKILL_LEVELS, SAMPLE_CODES } from '../constants/samples';

export default function Header({
  language,
  setLanguage,
  skillLevel,
  setSkillLevel,
  selectedSample,
  onSelectSample,
  onResetCode,
  onAnalyze,
  analyzing,
  apiKey,
  serverStatus,
  onOpenApiKeyModal,
  onOpenHistory,
  user,
  onOpenLogin
}) {
  const isApiConnected = !!(apiKey || serverStatus?.hasEnvKey);
  const activeProvider = serverStatus?.provider === 'gemini' 
    ? 'Gemini 3.5' 
    : serverStatus?.provider === 'groq' 
    ? 'Groq' 
    : apiKey 
    ? 'OpenAI' 
    : 'Smart Engine';

  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[#070a12]/85 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl blur opacity-35 group-hover:opacity-75 transition duration-300"></div>
            <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-[#161f36] to-[#1e293b] border border-white/10 flex items-center justify-center text-indigo-400 shadow-md">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                CodeMentor <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">AI</span>
              </span>
              <span className="text-[10px] font-semibold tracking-wide px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">AI Code Reviewer & Student Debugging Suite</p>
          </div>
        </div>

        {/* Central Controls Bar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Preset Sample Selector */}
          <div className="relative">
            <select
              value={selectedSample}
              onChange={(e) => onSelectSample(e.target.value)}
              className="h-8.5 text-xs bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 rounded-lg pl-3 pr-7 text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition cursor-pointer appearance-none shadow-sm"
            >
              <option value="">⚡ Presets / Samples...</option>
              {SAMPLE_CODES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2.5 pointer-events-none" />
          </div>

          {/* Language Selector */}
          <div className="relative flex items-center">
            <Code2 className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 pointer-events-none" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="h-8.5 bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 rounded-lg pl-8 pr-7 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition cursor-pointer appearance-none shadow-sm"
            >
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.value} value={l.value} className="bg-slate-900 text-white">
                  {l.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 pointer-events-none" />
          </div>

          {/* Skill Level Selector */}
          <div className="relative flex items-center">
            <GraduationCap className="w-3.5 h-3.5 text-purple-400 absolute left-2.5 pointer-events-none" />
            <select
              value={skillLevel}
              onChange={(e) => setSkillLevel(e.target.value)}
              className="h-8.5 bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 rounded-lg pl-8 pr-7 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition cursor-pointer appearance-none shadow-sm"
            >
              {SKILL_LEVELS.map((s) => (
                <option key={s.value} value={s.value} className="bg-slate-900 text-white">
                  {s.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 pointer-events-none" />
          </div>

          {/* AI Engine Status Pill */}
          <button
            onClick={onOpenApiKeyModal}
            className={`h-8.5 px-3 rounded-lg text-xs font-medium flex items-center gap-2 border transition-all cursor-pointer shadow-sm ${
              isApiConnected
                ? 'bg-emerald-950/25 border-emerald-500/30 text-emerald-300 hover:bg-emerald-950/40 hover:border-emerald-500/50'
                : 'bg-amber-950/20 border-amber-500/30 text-amber-300 hover:bg-amber-950/35 hover:border-amber-500/50'
            }`}
            title="Configure AI API & Engine"
          >
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isApiConnected ? 'bg-emerald-400' : 'bg-amber-400'
              }`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                isApiConnected ? 'bg-emerald-500' : 'bg-amber-500'
              }`}></span>
            </span>
            <span className="font-medium text-[11px]">{activeProvider}</span>
            <Key className="w-3 h-3 text-slate-400 ml-0.5 opacity-60" />
          </button>

          {/* Database History button */}
          <button
            onClick={onOpenHistory}
            className="h-8.5 px-3 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1.5 transition cursor-pointer shadow-sm"
            title="Open Past Reviews History"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline text-[11px]">History</span>
          </button>

          {/* User Login / Profile Button */}
          {user ? (
            <button
              onClick={onOpenLogin}
              className="h-8.5 px-2.5 rounded-lg bg-indigo-950/40 border border-indigo-500/30 hover:border-indigo-500/60 text-indigo-200 text-xs font-medium flex items-center gap-2 transition cursor-pointer shadow-sm"
              title={`Logged in as ${user.email}`}
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center text-[10px] font-bold">
                {(user.name || user.email || 'U')[0].toUpperCase()}
              </div>
              <span className="hidden md:inline text-[11px] max-w-[100px] truncate font-medium">
                {user.name || user.email.split('@')[0]}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            </button>
          ) : (
            <button
              onClick={onOpenLogin}
              className="h-8.5 px-3 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-indigo-500/50 hover:text-white text-slate-300 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer shadow-sm"
              title="Sign in with Email"
            >
              <LogIn className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[11px]">Sign In</span>
            </button>
          )}

          {/* Clear / Reset button */}
          <button
            onClick={onResetCode}
            title="Reset Editor"
            className="h-8.5 px-2.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition border border-slate-800 hover:border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Main Action: Analyze Button */}
          <button
            onClick={onAnalyze}
            disabled={analyzing}
            className="h-8.5 px-4 rounded-lg bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-all transform active:scale-[0.98] disabled:opacity-50 cursor-pointer border border-indigo-400/20"
          >
            {analyzing ? (
              <>
                <Cpu className="w-3.5 h-3.5 animate-spin text-cyan-200" />
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 fill-current" />
                <span>Analyze Code</span>
                <span className="text-[10px] bg-indigo-950/60 px-1.5 py-0.5 rounded text-indigo-200 font-mono hidden md:inline ml-0.5 border border-indigo-500/30">
                  Ctrl+Enter
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
