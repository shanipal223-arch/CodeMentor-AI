# CodeMentor AI ⚡
> **Domain:** AI / Developer Tools  
> **Tech Stack:** MERN (MongoDB + Mongoose, Express.js, React 19, Node.js), Google Gemini & OpenAI API, Tailwind CSS, Lucide Icons

**CodeMentor AI** is an intelligent pairing and code quality platform tailored for students, junior developers, and educators. Users can paste code in multiple languages (Python, JavaScript, TypeScript, Java, C++, Go, etc.) and receive comprehensive, actionable, AI-generated feedback covering **critical bugs**, **algorithmic optimization (Big-O analysis)**, **clean code standards**, **systematic step-by-step debugging walkthroughs**, and **persistent review history stored in MongoDB**.

---

## 🌟 Key Features

### 1. 🍃 Persistent MongoDB Review History
- Built with **Mongoose ODM** storing submissions, ratings, bugs, optimizations, and refactored code directly as documents.
- Slide-over **Review History Drawer** allows students to reload any past review with one click.
- Works with **MongoDB Atlas** cloud clusters (`mongodb+srv://...`) or local instances, with an automatic resilient local file fallback (`server/data/reviews.json`).

### 2. 🚨 Precision Bug & Error Detection
- Identifies syntax errors, runtime hazards, off-by-one errors, infinite loops, null pointer dereferences, and resource leaks.
- Flags offending line numbers directly in the code editor margin.
- Delivers student-friendly explanations describing *why* the failure happens, alongside concrete fix snippets.

### 3. ⚡ Algorithmic Optimization & Big-O Analysis
- Analyzes time and space complexity with clear before/after comparisons (e.g., $O(n^2) \rightarrow O(n)$).
- Explains quadratic and exponential bottlenecks (nested loops, unmemoized recursions).
- Teaches algorithmic patterns (Hash Maps, Two-Pointers, Memoization, Sliding Windows).

### 4. 🧼 Clean Code Standards & Best Practices
- Evaluates code against industry standards: DRY (Don't Repeat Yourself), SOLID principles, self-documenting naming conventions, and defensive guard clauses.
- Provides concise before-and-after code snippets showing clean refactorings.

### 5. 🎓 Interactive Student Debugging Guide
- **Engineering Mental Model**: Intuitive metaphors for understanding program state.
- **Step-by-Step Debugging Walkthrough**: How a senior engineer isolates, traces, and verifies the problem.
- **Critical Edge Cases**: Checklists of edge cases (empty arrays, boundary values, negative numbers, singletons) to test before submission.

### 6. 🔄 Refactored Code with One-Click Apply
- Provides complete, production-grade refactored code with explanatory comments.
- Students can copy the code or click **"Apply to Editor"** to immediately test the improved version.

### 7. 🧪 Automated Edge-Case Test Suite Generator
- Generates test cases (pytest, Jest, JUnit) covering standard and edge cases.

### 8. 💬 Integrated AI Code Tutor Chat
- Students can ask follow-up questions about their specific code snippet (e.g., *"Why is my recursive solution so slow?"*, *"Can you explain with a real-life analogy?"*).

### 9. 🔌 Multi-Provider AI Support
- **Google Gemini API** (`gemini-3.5-flash-lite`, `gemini-3.5-flash` - 100% Free with no credit card required).
- **OpenAI API** (`gpt-4o-mini`, `gpt-4o`).
- **Groq API** (Llama 3.3 70B).
- **Built-in Smart Offline Engine** for zero-cost instant testing.

---

## 🏗️ Architecture

```
MM 1/
├── server/                    # Node.js + Express Backend
│   ├── models/
│   │   └── Review.js          # Mongoose Review Schema
│   ├── db.js                  # MongoDB / Mongoose connection & resilient data layer
│   ├── index.js               # API routes, AI integrations, history endpoints
│   ├── .env.example           # Environment template (OPENAI, GEMINI, MONGODB_URI)
│   ├── .env                   # Active environment config
│   └── package.json
├── client/                    # React 19 Frontend (Vite + Tailwind CSS)
│   ├── src/
│   │   ├── components/
│   │   │   ├── Header.jsx           # Navbar with presets, API status, History trigger
│   │   │   ├── HistoryDrawer.jsx    # MongoDB history drawer with review loader
│   │   │   ├── EditorPanel.jsx      # Code editor with line numbers & shortcuts
│   │   │   ├── HealthScoreCard.jsx  # Health score (0-100) & dimension metrics
│   │   │   ├── AnalysisResults.jsx  # Tabbed results (Bugs, Big-O, Clean Code, Guide)
│   │   │   ├── StudentTutorChat.jsx # Interactive student tutor Q&A
│   │   │   └── ApiKeyModal.jsx      # Multi-provider API configuration modal
│   │   ├── constants/
│   │   │   └── samples.js           # Student code presets across 6+ languages
│   │   ├── App.jsx                  # Main workspace state & layout
│   │   ├── index.css                # Tailwind CSS styling & custom scrollbars
│   │   └── main.jsx
│   ├── vite.config.js               # Vite config with API proxy to port 5000
│   └── package.json
├── package.json               # Root scripts to run both client and server
└── README.md
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js** v18+ (tested on Node.js v24)
- **npm** v9+

### 1. Install Dependencies
Run the install command from the root directory:
```bash
npm run install:all
```

---

### 2. Configure MongoDB & AI Keys (Optional)
Open `server/.env` to configure your keys:

```env
# Google Gemini API Key (100% Free at aistudio.google.com/apikey)
GEMINI_API_KEY=your_key_here

# OR OpenAI API Key (platform.openai.com)
OPENAI_API_KEY=

# MongoDB Connection String (Local or MongoDB Atlas)
MONGODB_URI=mongodb://127.0.0.1:27017/codementor

PORT=5000
```

> **Note:** If MongoDB is not connected, the server automatically uses a local JSON database (`server/data/reviews.json`), so all reviews, history, and deletions work out-of-the-box!

---

### 3. Run the Application
From the root directory:
```bash
npm run dev
```

This concurrently launches:
- 💻 **React Frontend:** [http://localhost:3000](http://localhost:3000)
- 🚀 **Node.js Backend:** [http://localhost:5000](http://localhost:5000)

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/status` | Checks server health, AI key status, and MongoDB state |
| `POST` | `/api/analyze` | Analyzes code for errors, Big-O, best practices, and auto-saves to MongoDB |
| `GET` | `/api/history` | Fetches list of past reviews from MongoDB |
| `GET` | `/api/history/:id` | Loads full review document by ID |
| `DELETE` | `/api/history/:id` | Deletes a review from MongoDB |
| `POST` | `/api/save-mongo-uri` | Updates MongoDB connection string dynamically |
| `POST` | `/api/chat` | Interactive student tutor chat |
| `POST` | `/api/generate-tests` | Synthesizes automated test cases |
