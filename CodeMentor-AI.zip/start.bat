@echo off
title CodeMentor AI Launcher
echo ==============================================
echo        Starting CodeMentor AI Platform
echo ==============================================
echo.
echo Starting Backend (Port 5000) and Frontend (Port 3000)...
echo.
cd /d "%~dp0"
call npm run dev
pause
