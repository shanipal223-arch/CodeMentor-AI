import mongoose from 'mongoose';

const ReviewSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      default: 'Code Review'
    },
    userEmail: {
      type: String,
      default: '',
      index: true
    },
    code: {
      type: String,
      required: true
    },
    language: {
      type: String,
      default: 'javascript'
    },
    skillLevel: {
      type: String,
      default: 'beginner'
    },
    healthScore: {
      type: Number,
      required: true,
      min: 0,
      max: 100
    },
    ratings: {
      correctness: { type: Number, default: 0 },
      performance: { type: Number, default: 0 },
      readability: { type: Number, default: 0 },
      security: { type: Number, default: 0 }
    },
    summary: {
      type: String,
      default: ''
    },
    bugs: [
      {
        title: String,
        line: Number,
        severity: String,
        explanation: String,
        fix: String
      }
    ],
    optimizations: [
      {
        title: String,
        currentComplexity: String,
        optimizedComplexity: String,
        explanation: String,
        technique: String
      }
    ],
    bestPractices: [
      {
        category: String,
        tip: String,
        explanation: String,
        codeExample: String
      }
    ],
    debuggingGuide: {
      mentalModel: String,
      stepByStep: [String],
      edgeCasesToTest: [String]
    },
    refactoredCode: {
      type: String,
      default: ''
    },
    modelUsed: {
      type: String,
      default: 'AI'
    }
  },
  {
    timestamps: true
  }
);

export const Review = mongoose.models.Review || mongoose.model('Review', ReviewSchema);
