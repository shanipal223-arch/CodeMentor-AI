import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { 
  connectDB, 
  getMongoStatus, 
  saveReview, 
  getReviewHistory, 
  getReviewById, 
  deleteReviewById 
} from './db.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ENV_PATH = path.join(__dirname, '.env');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '2mb' }));

// Initialize MongoDB connection asynchronously
connectDB();

// Helper to detect provider type
function detectProvider(apiKey, explicitProvider) {
  if (explicitProvider) return explicitProvider;
  if (!apiKey) {
    if (process.env.GEMINI_API_KEY) return 'gemini';
    if (process.env.OPENAI_API_KEY?.startsWith('gsk_')) return 'groq';
    return 'openai';
  }
  if (apiKey.startsWith('AIza') || apiKey.startsWith('AQ.')) return 'gemini';
  if (apiKey.startsWith('gsk_')) return 'groq';
  return 'openai';
}

// Helper to check for common truncated key mistakes
function validateKeyFormat(key) {
  if (!key) return null;
  const trimmed = key.trim();
  if (trimmed.includes('...') || trimmed.includes('…')) {
    return "Your API key contains literal dots '...'. OpenAI masks keys with '...' in their dashboard table. You must create a new secret key at platform.openai.com/api-keys and copy the full key immediately from the creation popup before closing it.";
  }
  if (trimmed.startsWith('sk-') && trimmed.length < 30) {
    return `Your OpenAI API key is only ${trimmed.length} characters long. A full key is typically 50+ characters (starts with sk-proj- or sk-). Please generate a new key and copy the full text.`;
  }
  return null;
}

// Helper to instantiate OpenAI client
function getOpenAIClient(clientApiKey, clientBaseURL) {
  const key = clientApiKey || process.env.OPENAI_API_KEY;
  if (!key || key.trim() === '') {
    return null;
  }
  let baseURL = clientBaseURL || process.env.OPENAI_BASE_URL || undefined;
  if (key.trim().startsWith('gsk_') && !baseURL) {
    baseURL = 'https://api.groq.com/openai/v1';
  }

  return new OpenAI({
    apiKey: key.trim(),
    baseURL: baseURL || undefined
  });
}

// Health & configuration check
app.get('/api/status', (req, res) => {
  const hasOpenAI = !!(process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim() !== '' && !process.env.OPENAI_API_KEY.includes('...'));
  const hasGemini = !!(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() !== '');

  res.json({
    status: 'online',
    hasEnvKey: hasOpenAI || hasGemini,
    provider: hasGemini ? 'gemini' : 'openai',
    defaultModel: hasGemini ? 'gemini-3.5-flash-lite' : (process.env.OPENAI_MODEL || 'gpt-4o-mini'),
    baseURL: process.env.OPENAI_BASE_URL || null,
    mongo: getMongoStatus(),
    message: (hasOpenAI || hasGemini)
      ? `API key active in server .env (${hasGemini ? 'Google Gemini' : 'OpenAI'}).` 
      : 'No valid key in server .env. Running in Smart Demo Mode or waiting for client key.'
  });
});



// Prompt engineering for student-focused feedback
function buildAnalysisPrompt(code, language, skillLevel) {
  return `You are CodeMentor AI, a world-class senior software engineer and computer science educator.
A student or developer (${skillLevel || 'beginner/intermediate'} level) has submitted the following ${language || 'code'} snippet for review.

Analyze this code thoroughly and return a valid, strictly formatted JSON object with no wrapping markdown backticks, matching this exact schema:

{
  "summary": "Clear, friendly, 2-3 sentence overview of what the code does and the main findings.",
  "healthScore": 72, // integer between 0 and 100 based on correctness, efficiency, style, and security
  "ratings": {
    "correctness": 70, // 0-100
    "performance": 60, // 0-100
    "readability": 80, // 0-100
    "security": 85     // 0-100
  },
  "bugs": [
    {
      "title": "Short title of bug/error",
      "line": 4, // line number or null
      "severity": "critical" | "warning" | "info",
      "explanation": "Clear explanation tailored for a student on why this fails or causes unexpected behavior.",
      "fix": "Specific fix instruction or code snippet"
    }
  ],
  "optimizations": [
    {
      "title": "Optimization description (e.g., Replace O(n^2) nested loop with Hash Map)",
      "currentComplexity": "O(n^2) Time, O(1) Space",
      "optimizedComplexity": "O(n) Time, O(n) Space",
      "explanation": "Detailed explanation of algorithmic inefficiency and why the optimized approach is better.",
      "technique": "Data structure or algorithmic concept to study (e.g., Two-pointer, Hash Set, Memoization)"
    }
  ],
  "bestPractices": [
    {
      "category": "Naming Conventions" | "DRY Principle" | "Error Handling" | "Type Safety" | "Code Organization",
      "tip": "Actionable advice",
      "explanation": "Why this standard matters in modern industry codebases.",
      "codeExample": "Short before/after or illustration"
    }
  ],
  "debuggingGuide": {
    "mentalModel": "An intuitive metaphor or concept for how to think about this code flow.",
    "stepByStep": [
      "Step 1: Check inputs and boundary conditions...",
      "Step 2: Trace line X where variable Y changes...",
      "Step 3: Add print statement / breakpoint at line Z..."
    ],
    "edgeCasesToTest": [
      "Empty array / null input",
      "Single element",
      "Duplicate values",
      "Negative or extreme numbers"
    ]
  },
  "refactoredCode": "// Full, clean, beautifully formatted and commented refactored code adhering to all best practices"
}

STUDENT'S CODE:
\`\`\`${language}
${code}
\`\`\`

Ensure your feedback is encouraging, educational, and precise. Return ONLY valid JSON.`;
}

// Fallback intelligent analysis generator for offline/free testing
function generateFallbackAnalysis(code, language, skillLevel) {
  const codeLines = code.split('\n');
  const lineCount = codeLines.length;
  const isPython = /python/i.test(language);
  const isJS = /javascript|typescript/i.test(language);

  // Detect common code anti-patterns
  const hasNestedLoop = /(for|while).*[\s\S]*?(for|while)/i.test(code);
  const hasBareExcept = isPython && /except\s*:/i.test(code);
  const hasVarKeyword = isJS && /\bvar\b/.test(code);
  const hasDoubleEquals = isJS && /==(?!=)/.test(code);

  const bugs = [];
  const optimizations = [];
  const bestPractices = [];

  if (hasBareExcept) {
    bugs.push({
      title: "Broad / Bare 'except:' clause catches all exceptions",
      line: codeLines.findIndex(l => /except\s*:/.test(l)) + 1 || 1,
      severity: "warning",
      explanation: "Using bare 'except:' catches system interrupts (like KeyboardInterrupt, SystemExit) and conceals unexpected bugs.",
      fix: "Specify the exact exception: e.g., 'except (ValueError, KeyError) as e:'"
    });
  }

  if (hasVarKeyword) {
    bestPractices.push({
      category: "Code Organization",
      tip: "Use 'const' and 'let' instead of 'var'",
      explanation: "'var' has function scope and undergoes hoisting, which frequently causes subtle state leakage bugs in modern JavaScript.",
      codeExample: "// Instead of: var items = [];\n// Prefer: const items = [];"
    });
  }

  if (hasDoubleEquals) {
    bestPractices.push({
      category: "Type Safety",
      tip: "Use strict equality '===' instead of loose equality '=='",
      explanation: "Loose equality performs implicit type coercion, leading to counter-intuitive truths such as '0' == 0 and [] == false.",
      codeExample: "if (status === 'success') { ... }"
    });
  }

  if (hasNestedLoop) {
    optimizations.push({
      title: "Nested Loops creating O(n²) or higher quadratic complexity",
      currentComplexity: "O(n²) Time",
      optimizedComplexity: "O(n) Time using Lookup Map / Set",
      explanation: "Scanning inside an existing loop multiplies execution steps. For 100,000 items, O(n²) performs 10 billion operations, while O(n) takes only 100,000.",
      technique: "Hash Map / Set lookup or Pre-sorting with Two-Pointers"
    });
  } else {
    optimizations.push({
      title: "Pre-allocate collections or use early return guard clauses",
      currentComplexity: "Standard Linear / Sub-linear",
      optimizedComplexity: "Reduced memory allocations",
      explanation: "Returning early on invalid input saves unnecessary CPU cycles and nested indentation.",
      technique: "Guard Clauses & Fail-Fast Pattern"
    });
  }

  bestPractices.push({
    category: "Naming Conventions",
    tip: "Use descriptive, intention-revealing variable names",
    explanation: "Self-documenting variable names eliminate the need for redundant comments and clarify data flow.",
    codeExample: "// Instead of: const d = 86400;\n// Prefer: const SECONDS_PER_DAY = 86400;"
  });

  bestPractices.push({
    category: "Error Handling",
    tip: "Validate boundary conditions and input types at the entry point",
    explanation: "Defensive programming guarantees that unexpected inputs (null, undefined, negative indices) fail fast with clear errors.",
    codeExample: "if (!input || input.length === 0) return defaultValue;"
  });

  return {
    isMockFallback: true,
    summary: `Analyzed ${lineCount} lines of ${language} code. Identified ${bugs.length} potential warning(s), ${optimizations.length} algorithmic optimization opportunities, and clean code suggestions for ${skillLevel || 'students'}.`,
    healthScore: bugs.length > 0 ? 74 : (hasNestedLoop ? 82 : 89),
    ratings: {
      correctness: bugs.length > 0 ? 75 : 90,
      performance: hasNestedLoop ? 65 : 88,
      readability: hasVarKeyword ? 70 : 85,
      security: 82
    },
    bugs: bugs.length > 0 ? bugs : [
      {
        title: "Ensure edge condition checks for empty/null structures",
        line: 1,
        severity: "info",
        explanation: "Always confirm that the target sequence contains elements before dereferencing indices.",
        fix: "Add guard check: if len(items) == 0: return None"
      }
    ],
    optimizations,
    bestPractices,
    debuggingGuide: {
      mentalModel: "Think of your data pipeline like an assembly line: each function should take clean inputs, execute one single responsibility, and return a predictable output.",
      stepByStep: [
        "1. Write down expected inputs and what the exact return value should look like.",
        "2. Place print / logger statements before and after conditional checks.",
        "3. Test the boundary: pass an empty input array, single element array, and large sample.",
        "4. Profile execution time with large inputs to verify complexity."
      ],
      edgeCasesToTest: [
        "Empty collections ([] or {})",
        "Collections with duplicate values",
        "Single element collections",
      ]
    },
    refactoredCode: `// Refactored ${language} code following clean architecture\n// 1. Descriptive naming\n// 2. Guard clauses for edge cases\n// 3. Clear comments\n\n` + code
  };
}



// Robust JSON parser for LLM responses
function safeParseJSON(str) {
  try {
    return JSON.parse(str);
  } catch (err) {
    let cleaned = str.replace(/```json/gi, '').replace(/```/g, '').trim();
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
      cleaned = cleaned.substring(start, end + 1);
    }
    // Remove trailing commas before } or ]
    cleaned = cleaned.replace(/,\s*([}\]])/g, '$1');
    try {
      return JSON.parse(cleaned);
    } catch (e2) {
      // Fix unescaped control characters inside strings
      cleaned = cleaned.replace(/[\x00-\x1F\x7F]/g, (c) => {
        if (c === '\n') return '\\n';
        if (c === '\r') return '\\r';
        if (c === '\t') return '\\t';
        return '';
      });
      return JSON.parse(cleaned);
    }
  }
}

// Resilient Gemini generator with automatic model fallback
async function generateWithGemini(key, prompt, jsonMode = false, preferredModel = null) {

  const genAI = new GoogleGenerativeAI(key.trim());
  const modelsToTry = [
    preferredModel,
    'gemini-3.5-flash-lite',
    'gemini-flash-latest',
    'gemini-3.5-flash',
    'gemini-2.5-pro'
  ].filter(Boolean);

  const uniqueModels = [...new Set(modelsToTry)];
  let lastError = null;

  for (const modelName of uniqueModels) {
    try {
      const config = jsonMode ? { responseMimeType: 'application/json' } : {};
      const model = genAI.getGenerativeModel({ model: modelName, generationConfig: config });
      const result = await model.generateContent(prompt);
      return {
        text: result.response.text(),
        modelUsed: modelName
      };
    } catch (err) {
      lastError = err;
      const isRecoverable = err.message && (
        err.message.includes('404') || 
        err.message.includes('503') || 
        err.message.includes('high demand') || 
        err.message.includes('not found') || 
        err.message.includes('no longer available') ||
        err.message.includes('RESOURCE_EXHAUSTED') ||
        err.message.includes('temporarily')
      );
      if (isRecoverable) {
        console.warn(`[Gemini Fallback] Model ${modelName} returned temporary error. Trying next model...`);
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

// POST /api/test-key - Test any API key against OpenAI or Gemini
app.post('/api/test-key', async (req, res) => {
  const { apiKey, baseURL, model, provider } = req.body;
  const key = apiKey || process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;

  if (!key || key.trim() === '') {
    return res.status(400).json({ success: false, message: 'Please provide an API key to test.' });
  }

  // Check for truncated/masked keys
  const formatError = validateKeyFormat(key);
  if (formatError) {
    return res.status(400).json({ success: false, message: formatError, status: 'truncated_key' });
  }

  const detectedProvider = detectProvider(key, provider);

  if (detectedProvider === 'gemini') {
    try {
      const response = await generateWithGemini(key, 'Say "connected" in one word.', false, model);
      const reply = response.text.trim();
      return res.json({
        success: true,
        provider: 'gemini',
        message: `Google Gemini API verified! (${response.modelUsed}) responded: "${reply}"`,
        modelUsed: response.modelUsed
      });
    } catch (err) {
      return res.status(400).json({
        success: false,
        provider: 'gemini',
        message: err.message || 'Failed to authenticate with Google Gemini API.'
      });
    }
  }



  // OpenAI testing
  const client = getOpenAIClient(key, baseURL);
  try {
    const selectedModel = model || process.env.OPENAI_MODEL || 'gpt-4o-mini';
    const testCompletion = await client.chat.completions.create({
      model: selectedModel,
      messages: [{ role: 'user', content: 'Say "connected" in one word.' }],
      max_tokens: 5
    });

    const reply = testCompletion.choices[0]?.message?.content?.trim();
    res.json({
      success: true,
      provider: 'openai',
      message: `OpenAI API connection verified successfully! Model responded: "${reply}"`,
      modelUsed: selectedModel
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      provider: 'openai',
      message: err.message || 'Failed to authenticate with OpenAI API',
      status: err.status
    });
  }
});

// POST /api/save-key - Persist API key to server/.env
app.post('/api/save-key', (req, res) => {
  const { apiKey, baseURL, model, provider } = req.body;
  if (!apiKey || apiKey.trim() === '') {
    return res.status(400).json({ error: 'API key is required.' });
  }

  const formatError = validateKeyFormat(apiKey);
  if (formatError) {
    return res.status(400).json({ error: formatError });
  }

  try {
    const detected = detectProvider(apiKey, provider);
    let envContent = '';

    if (detected === 'gemini') {
      process.env.GEMINI_API_KEY = apiKey.trim();
      envContent = `GEMINI_API_KEY=${apiKey.trim()}\nPORT=${process.env.PORT || 5000}\n`;
    } else {
      process.env.OPENAI_API_KEY = apiKey.trim();
      if (baseURL) process.env.OPENAI_BASE_URL = baseURL.trim();
      if (model) process.env.OPENAI_MODEL = model.trim();

      envContent = [
        `OPENAI_API_KEY=${apiKey.trim()}`,
        `PORT=${process.env.PORT || 5000}`,
        `OPENAI_MODEL=${model ? model.trim() : (process.env.OPENAI_MODEL || 'gpt-4o-mini')}`,
        baseURL ? `OPENAI_BASE_URL=${baseURL.trim()}` : ''
      ].filter(Boolean).join('\n') + '\n';
    }

    fs.writeFileSync(ENV_PATH, envContent, 'utf-8');

    res.json({
      success: true,
      message: 'API key successfully saved to server/.env and active in memory!'
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to write .env file: ' + err.message });
  }
});

// POST /api/auth/login - Student login with Email ID
app.post('/api/auth/login', (req, res) => {
  const { email, name } = req.body;
  if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return res.status(400).json({ error: 'Please provide a valid email address.' });
  }

  const cleanEmail = email.trim().toLowerCase();
  const userName = (name && typeof name === 'string' && name.trim()) 
    ? name.trim() 
    : cleanEmail.split('@')[0];

  res.json({
    success: true,
    user: {
      email: cleanEmail,
      name: userName,
      loginAt: new Date().toISOString()
    },
    message: `Welcome back, ${userName}!`
  });
});

// GET /api/history - Get list of past reviews from MongoDB / local store
app.get('/api/history', async (req, res) => {
  try {
    const userEmail = req.query.email ? req.query.email.trim().toLowerCase() : null;
    const history = await getReviewHistory(30, userEmail);
    res.json({ 
      history, 
      mongo: getMongoStatus() 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/history/:id - Fetch single review by ID
app.get('/api/history/:id', async (req, res) => {
  try {
    const review = await getReviewById(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found in database' });
    res.json(review);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/history/:id - Delete a review from database
app.delete('/api/history/:id', async (req, res) => {
  try {
    await deleteReviewById(req.params.id);
    res.json({ success: true, message: 'Review deleted from database' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/save-mongo-uri - Configure MongoDB connection URI
app.post('/api/save-mongo-uri', async (req, res) => {
  const { uri } = req.body;
  if (!uri || uri.trim() === '') {
    return res.status(400).json({ error: 'MongoDB connection string is required.' });
  }

  try {
    process.env.MONGODB_URI = uri.trim();
    let envContent = '';
    if (fs.existsSync(ENV_PATH)) {
      envContent = fs.readFileSync(ENV_PATH, 'utf-8');
      if (envContent.includes('MONGODB_URI=')) {
        envContent = envContent.replace(/MONGODB_URI=.*/g, `MONGODB_URI=${uri.trim()}`);
      } else {
        envContent = envContent.trim() + `\nMONGODB_URI=${uri.trim()}\n`;
      }
    } else {
      envContent = `MONGODB_URI=${uri.trim()}\nPORT=5000\n`;
    }
    fs.writeFileSync(ENV_PATH, envContent, 'utf-8');

    const connected = await connectDB();
    res.json({
      success: true,
      connected,
      mongo: getMongoStatus(),
      message: connected 
        ? '🍃 Connected to MongoDB successfully!' 
        : 'Saved MONGODB_URI to .env, but connection failed or timed out. Running in fallback mode.'
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to configure MongoDB: ' + err.message });
  }
});

// POST /api/analyze - Main code analysis endpoint
app.post('/api/analyze', async (req, res) => {

  const { code, language = 'javascript', skillLevel = 'beginner', apiKey, provider, userEmail } = req.body;

  if (!code || typeof code !== 'string' || code.trim() === '') {
    return res.status(400).json({ error: 'Code snippet is required for analysis.' });
  }

  const keyToUse = apiKey || process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;

  // Validate format
  const formatError = validateKeyFormat(keyToUse);
  if (formatError) {
    const fallback = generateFallbackAnalysis(code, language, skillLevel);
    return res.json({
      ...fallback,
      mode: 'fallback_error',
      apiError: {
        type: 'truncated_key',
        details: formatError
      }
    });
  }

  const detectedProvider = detectProvider(keyToUse, provider);

  // Gemini Handler
  if (detectedProvider === 'gemini' && keyToUse) {
    try {
      const prompt = buildAnalysisPrompt(code, language, skillLevel);
      const geminiRes = await generateWithGemini(keyToUse, prompt, true, req.body.model);
      const parsed = safeParseJSON(geminiRes.text);

      const savedDoc = await saveReview({
        userEmail: userEmail || '',
        code,
        language,
        skillLevel,
        healthScore: parsed.healthScore,
        ratings: parsed.ratings,
        summary: parsed.summary,
        bugs: parsed.bugs,
        optimizations: parsed.optimizations,
        bestPractices: parsed.bestPractices,
        debuggingGuide: parsed.debuggingGuide,
        refactoredCode: parsed.refactoredCode,
        modelUsed: `${geminiRes.modelUsed} (Google AI)`
      });

      return res.json({
        ...parsed,
        savedId: savedDoc?._id,
        mode: 'live_openai',
        modelUsed: `${geminiRes.modelUsed} (Google AI)`
      });

    } catch (err) {
      console.error('Gemini API Error:', err.message);
      const fallback = generateFallbackAnalysis(code, language, skillLevel);
      const savedDoc = await saveReview({ userEmail: userEmail || '', code, language, skillLevel, ...fallback, modelUsed: 'Smart Fallback' });
      return res.json({
        ...fallback,
        savedId: savedDoc?._id,
        mode: 'fallback_error',
        apiError: {
          message: err.message,
          details: `Google Gemini Error: ${err.message}. Switched to offline smart engine.`
        }
      });
    }
  }


  // OpenAI Handler
  const openai = getOpenAIClient(apiKey);
  if (!openai) {
    const fallback = generateFallbackAnalysis(code, language, skillLevel);
    const savedDoc = await saveReview({ userEmail: userEmail || '', code, language, skillLevel, ...fallback, modelUsed: 'Smart Fallback' });
    return res.json({
      ...fallback,
      savedId: savedDoc?._id,
      mode: 'offline_demo',
      notice: 'Connected in offline demo mode. Provide a valid OpenAI or Gemini API key in settings or server .env.'
    });
  }

  try {
    const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
    const completion = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: 'system',
          content: 'You are CodeMentor AI, an expert code analyzer and educator for students. Return only valid raw JSON adhering to the specified format.'
        },
        {
          role: 'user',
          content: buildAnalysisPrompt(code, language, skillLevel)
        }
      ],
      temperature: 0.2,
      response_format: { type: 'json_object' }
    });

    const rawResponse = completion.choices[0]?.message?.content || '{}';
    const parsed = safeParseJSON(rawResponse);

    const savedDoc = await saveReview({
      userEmail: userEmail || '',
      code,
      language,
      skillLevel,
      healthScore: parsed.healthScore,
      ratings: parsed.ratings,
      summary: parsed.summary,
      bugs: parsed.bugs,
      optimizations: parsed.optimizations,
      bestPractices: parsed.bestPractices,
      debuggingGuide: parsed.debuggingGuide,
      refactoredCode: parsed.refactoredCode,
      modelUsed: model
    });

    res.json({
      ...parsed,
      savedId: savedDoc?._id,
      mode: 'live_openai',
      modelUsed: model
    });

  } catch (error) {
    console.error('OpenAI API Error:', error.message);
    const isAuthError = error.status === 401 || /key/i.test(error.message);
    const isQuotaError = error.status === 429 || /quota|rate limit/i.test(error.message);

    const fallback = generateFallbackAnalysis(code, language, skillLevel);
    res.json({
      ...fallback,
      mode: 'fallback_error',
      apiError: {
        message: error.message,
        type: isAuthError ? 'auth_error' : isQuotaError ? 'quota_error' : 'network_error',
        details: isAuthError 
          ? 'The provided OpenAI API key appears invalid or expired. Switched to offline smart engine.'
          : isQuotaError
          ? 'OpenAI credit quota exceeded (check billing on platform.openai.com). Switched to offline smart engine.'
          : `API Error: ${error.message}`
      }
    });
  }
});

// POST /api/chat - Interactive student mentor chat
app.post('/api/chat', async (req, res) => {
  const { code, language, analysis, message, conversationHistory = [], apiKey, provider } = req.body;

  if (!message || message.trim() === '') {
    return res.status(400).json({ error: 'Message is required.' });
  }

  const keyToUse = apiKey || process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;
  if (!keyToUse) {
    return res.json({
      reply: `[Smart Assistant (Demo Mode)]: Great question about ${language || 'your code'}! To get live interactive answers from AI models, please connect a valid OpenAI or Google Gemini API key.\n\nGeneral Student Tip: Whenever you're tackling "${message.slice(0, 40)}...", remember to trace your variables line by line, verify input constraints, and ensure each function does only one thing.`
    });
  }

  const detectedProvider = detectProvider(keyToUse, provider);

  if (detectedProvider === 'gemini') {
    try {
      const prompt = `You are CodeMentor AI, a patient, inspiring programming tutor for students.
STUDENT CODE (${language}):
\`\`\`${language}
${code || '// No code provided'}
\`\`\`

STUDENT'S QUESTION:
${message}`;
      const geminiRes = await generateWithGemini(keyToUse, prompt, false, req.body.model);
      return res.json({ reply: geminiRes.text });

    } catch (err) {
      return res.json({ reply: `Error communicating with Gemini: ${err.message}` });
    }
  }

  const openai = getOpenAIClient(apiKey);
  try {
    const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
    const messages = [
      {
        role: 'system',
        content: `You are CodeMentor AI, a patient, inspiring programming tutor helping a student understand clean coding standards, optimization, and debugging. Explain the "why", not just the "how".`
      },
      {
        role: 'user',
        content: `Code (${language}):\n\`\`\`${language}\n${code}\n\`\`\``
      },
      ...conversationHistory.slice(-8),
      { role: 'user', content: message }
    ];

    const completion = await openai.chat.completions.create({
      model,
      messages,
      temperature: 0.6,
      max_tokens: 600
    });

    res.json({ reply: completion.choices[0]?.message?.content || 'No response generated.' });
  } catch (error) {
    res.json({ reply: `Error from OpenAI: ${error.message}. Please verify your key quota.` });
  }
});

// POST /api/generate-tests
app.post('/api/generate-tests', async (req, res) => {
  const { code, language = 'javascript', apiKey } = req.body;
  const keyToUse = apiKey || process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;

  if (!keyToUse) {
    return res.json({
      testCode: `// Sample Unit Tests for ${language}\n// (Connect OpenAI or Gemini API for automated test synthesis)\n\ndescribe('Verification', () => {\n  test('handles valid input', () => {\n    // verify expected output\n  });\n  test('handles empty boundary conditions', () => {\n    // test edge cases\n  });\n});`
    });
  }

  const detected = detectProvider(keyToUse);
  if (detected === 'gemini') {
    try {
      const prompt = `Write a comprehensive, student-friendly unit test suite for this ${language} code:\n\`\`\`${language}\n${code}\n\`\`\``;
      const geminiRes = await generateWithGemini(keyToUse, prompt);
      return res.json({ testCode: geminiRes.text });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }


  const openai = getOpenAIClient(apiKey);
  try {
    const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
    const completion = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: 'system',
          content: `Generate clean unit tests for ${language} covering happy paths and edge cases.`
        },
        {
          role: 'user',
          content: `Write unit tests for:\n\`\`\`${language}\n${code}\n\`\`\``
        }
      ],
      temperature: 0.2
    });
    res.json({ testCode: completion.choices[0]?.message?.content });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Serve static client build in production
const clientDistPath = path.join(__dirname, '../client/dist');
if (fs.existsSync(clientDistPath)) {
  app.use(express.static(clientDistPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`🚀 CodeMentor AI Backend listening on http://localhost:${PORT}`);
  console.log(`📡 OpenAI Key configured in env: ${!!process.env.OPENAI_API_KEY}`);
  console.log(`📡 Gemini Key configured in env: ${!!process.env.GEMINI_API_KEY}`);
});
