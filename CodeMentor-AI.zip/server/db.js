import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Review } from './models/Review.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, 'data');
const LOCAL_DB_FILE = path.join(DATA_DIR, 'reviews.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

let isMongoConnected = false;

// Fallback helper to read local JSON store
function readLocalReviews() {
  try {
    if (fs.existsSync(LOCAL_DB_FILE)) {
      const data = fs.readFileSync(LOCAL_DB_FILE, 'utf-8');
      return JSON.parse(data || '[]');
    }
  } catch (e) {
    console.error('Error reading local JSON db:', e.message);
  }
  return [];
}

// Fallback helper to write local JSON store
function writeLocalReviews(reviews) {
  try {
    fs.writeFileSync(LOCAL_DB_FILE, JSON.stringify(reviews, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error writing local JSON db:', e.message);
  }
}

// Connect to MongoDB
export async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri || uri.trim() === '') {
    console.log('🍃 MONGODB_URI not set. Using local file storage fallback (server/data/reviews.json).');
    isMongoConnected = false;
    return false;
  }

  try {
    // 5 second connection timeout so it fails fast if offline
    await mongoose.connect(uri.trim(), {
      serverSelectionTimeoutMS: 5000,
    });
    isMongoConnected = true;
    console.log(`🍃 Connected to MongoDB successfully! (${mongoose.connection.host})`);
    return true;
  } catch (err) {
    console.warn(`🍃 Could not connect to MongoDB: ${err.message}. Running in local storage fallback mode.`);
    isMongoConnected = false;
    return false;
  }
}

export function getMongoStatus() {
  return {
    connected: isMongoConnected && mongoose.connection.readyState === 1,
    state: isMongoConnected ? 'connected' : 'local_fallback',
    uri: process.env.MONGODB_URI ? 'Configured' : 'Not set',
    host: isMongoConnected ? mongoose.connection.host : 'Local JSON Store'
  };
}

// Save a code review to database
export async function saveReview(data) {
  const reviewDoc = {
    title: data.title || `${data.language || 'Code'} Review (${data.healthScore || 0}%)`,
    userEmail: data.userEmail || '',
    code: data.code,
    language: data.language || 'javascript',
    skillLevel: data.skillLevel || 'beginner',
    healthScore: data.healthScore || 0,
    ratings: data.ratings || {},
    summary: data.summary || '',
    bugs: data.bugs || [],
    optimizations: data.optimizations || [],
    bestPractices: data.bestPractices || [],
    debuggingGuide: data.debuggingGuide || {},
    refactoredCode: data.refactoredCode || '',
    modelUsed: data.modelUsed || 'AI'
  };

  if (isMongoConnected && mongoose.connection.readyState === 1) {
    try {
      const saved = await Review.create(reviewDoc);
      return saved.toObject();
    } catch (err) {
      console.error('MongoDB save error, falling back to local file:', err.message);
    }
  }

  // Local JSON fallback
  const reviews = readLocalReviews();
  const fallbackDoc = {
    _id: 'rev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
    ...reviewDoc,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  reviews.unshift(fallbackDoc);
  // Keep max 50 reviews locally
  if (reviews.length > 50) reviews.pop();
  writeLocalReviews(reviews);
  return fallbackDoc;
}

// Fetch review history list (newest first)
export async function getReviewHistory(limit = 20, userEmail = null) {
  const query = userEmail ? { userEmail } : {};
  if (isMongoConnected && mongoose.connection.readyState === 1) {
    try {
      return await Review.find(query, {
        _id: 1,
        title: 1,
        userEmail: 1,
        language: 1,
        healthScore: 1,
        bugs: 1,
        createdAt: 1,
        summary: 1
      })
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean();
    } catch (err) {
      console.error('MongoDB find error, using local fallback:', err.message);
    }
  }

  // Local JSON fallback
  const reviews = readLocalReviews();
  const filtered = userEmail ? reviews.filter(r => !r.userEmail || r.userEmail === userEmail) : reviews;
  return filtered.slice(0, limit).map(r => ({
    _id: r._id,
    title: r.title,
    userEmail: r.userEmail || '',
    language: r.language,
    healthScore: r.healthScore,
    bugs: r.bugs || [],
    createdAt: r.createdAt,
    summary: r.summary
  }));
}

// Fetch single review by ID
export async function getReviewById(id) {
  if (isMongoConnected && mongoose.connection.readyState === 1) {
    try {
      if (mongoose.Types.ObjectId.isValid(id)) {
        const doc = await Review.findById(id).lean();
        if (doc) return doc;
      }
    } catch (err) {
      console.error('MongoDB findById error:', err.message);
    }
  }

  // Local JSON fallback
  const reviews = readLocalReviews();
  return reviews.find(r => r._id === id) || null;
}

// Delete review by ID
export async function deleteReviewById(id) {
  if (isMongoConnected && mongoose.connection.readyState === 1) {
    try {
      if (mongoose.Types.ObjectId.isValid(id)) {
        await Review.findByIdAndDelete(id);
        return true;
      }
    } catch (err) {
      console.error('MongoDB delete error:', err.message);
    }
  }

  // Local JSON fallback
  const reviews = readLocalReviews();
  const filtered = reviews.filter(r => r._id !== id);
  writeLocalReviews(filtered);
  return true;
}
